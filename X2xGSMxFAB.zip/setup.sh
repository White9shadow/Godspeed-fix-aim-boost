SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=true
MODDIR=/data/adb/modules
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'sys/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'tmp/*' -d $MODPATH >&2
ui_print "
┏━━━┳━━━┳━┓┏━┓*****┏━━━┳━━━┳━━┓
┃┏━┓┃┏━┓┃┃┗┛┃┃*****┃┏━━┫┏━┓┃┏┓┃
┃┃╋┗┫┗━━┫┏┓┏┓┃*****┃┗━━┫┃╋┃┃┗┛┗┓
┃┃┏━╋━━┓┃┃┃┃┃┃*****┃┏━━┫┗━┛┃┏━┓┃
┃┗┻━┃┗━┛┃┃┃┃┃┃*****┃┃╋╋┃┏━┓┃┗━┛┃
┗━━━┻━━━┻┛┗┛┗┛*****┗┛╋╋┗┛╋┗┻━━━┛original"
ui_print "▌GODSPEED FIX AIM BOOST"
ui_print "▌VERSION : X2 "
ui_print "▌CODENAME - Drifters "
sleep 1
ui_print "▌DEVICE INFORMATION: "
sleep 0.2
ui_print "▌DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "▌BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "▌MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "▌KERNEL : $(uname -r) "
sleep 0.2
ui_print "▌PROCESSOR : $(getprop ro.product.board) "
ui_print "▌Remove Other OPTIMIZER for Better performance,"
sleep 1
sleep 1
  ui_print "▌ADDING GAMES TO MAGISKHIDE PLOX WAIT"
  ui_print "▌"
  sleep 1.5
  ui_print "▌ENABLING MAGISKHIDE"
magiskhide disable >/dev/null 2>&1
magiskhide enable >/dev/null 2>&1
magisk --denylist enable >/dev/null 2>&1
sleep 1.5
ui_print "▌MAGISK HIDE ENABLED"
sleep 1.5
ui_print ""
ui_print "▌ADDING GAMES"
am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/u0xs36mu8?key=813a284c6297605783693cce073b8e99 >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
magiskhide add com.tencent.ig >/dev/null 2>&1
magiskhide add com.epicgames.fortnite >/dev/null 2>&1
magiskhide add com.vng.pubgmobile >/dev/null 2>&1
magiskhide add com.pubg.krmobile >/dev/null 2>&1
magiskhide add com.activision.callofduty.shooter >/dev/null 2>&1
magiskhide add com.garena.game.codm >/dev/null 2>&1
magiskhide add com.pubg.newstate >/dev/null 2>&1
magiskhide add com.plato.android >/dev/null 2>&1
magiskhide add com.dts.freefireth >/dev/null 2>&1
magiskhide add com.dts.freefiremax >/dev/null 2>&1
magiskhide add com.kitkagames.fallbuddies >/dev/null 2>&1
magiskhide add com.ea.gp.apexlegendsmobilefps >/dev/null 2>&1
magisk --denylist add com.pubg.newstate >/dev/null 2>&1
magisk --denylist add com.garena.game.codm >/dev/null 2>&1
magisk --denylist add com.activision.callofduty.shooter >/dev/null 2>&1
magisk --denylist add com.pubg.krmobile >/dev/null 2>&1
magisk --denylist add com.epicgames.fortnite >/dev/null 2>&1
magisk --denylist add com.tencent.ig >/dev/null 2>&1
magisk --denylist add com.plato.android >/dev/null 2>&1
magisk --denylist add com.dts.freefireth >/dev/null 2>&1
magisk --denylist add com.dts.freefiremax >/dev/null 2>&1
magisk --denylist add com.kitkagames.fallbuddies >/dev/null 2>&1
magisk --denylist add com.ea.gp.apexlegendsmobilefps >/dev/null 2>&1
sleep 1
ui_print "▌ALL GAMES ADDED SUCCESSFULLY "
sleep 1
ui_print "▌INSTALLING FAB"
unzip -o "$ZIPFILE" 'fab/*' -d "$TMPDIR" >&2 && cp -af "$TMPDIR"/fab/* "$MODPATH"/config
sleep 3
ui_print "▌INSTALLED GODSPEED FIX AIM BOOST "
ui_print "▌A module by @revWhiteShadow "
ui_print "▌support channel @godTspeed | @godspeedmode "
am start -a android.intent.action.VIEW -d https://t.me/godtspeed >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/godspeedmode >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
ui_print "▌Visit Our website for more gaming stuffs "
ui_print "▌www.godtspeed.xyz"
am start -a android.intent.action.VIEW -d https://godtspeed.xyz >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
ui_print "▌SettingUp Permissions "
sleep 3

set_permissions() {
set_perm_recursive $MODPATH/config 0 0 0755 0755
set_perm_recursive $MODPATH/system/* 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin/fab" 0 0 0755 0755
}
